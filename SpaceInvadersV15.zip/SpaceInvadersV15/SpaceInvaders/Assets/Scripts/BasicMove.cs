﻿using UnityEngine;
using System.Collections;

public class BasicMove : MonoBehaviour {

	public bool horizontalBoundary = true;
	public float speed = 1f;
	public bool facingRight = true;
	public float h;
	public bool boundaryFlag = true;
	
	// Update is called once per frame
	void Update () {
		h = Input.GetAxis("Horizontal") * speed;
		////float step = speed;
		// move speed meters per sec
		/*if (horizontalBoundary) 	{
				h = - h;
		}
		*/
		if (boundaryFlag) {
			transform.Translate (h, 0f, 0f);
		}


		//Debug.Log("Sphere: position: "+transform.position.ToString());

		// check if out of bound, if so reverse direction

		/***if (transform.position.y > 3f) {
				up = false;
		}
		if (transform.position.y < -3f) {
				up = true;
		}
		***/
		if (transform.position.x >= 8f) {
			//Flip();
			boundaryFlag = false;
			//bool flipDirection = true;
			//h = -h;
		}
		if (transform.position.x <= -8f) {
			//Flip ();
			boundaryFlag = false;
			//h = -h;
		}
		if (Input.GetKey (KeyCode.LeftArrow) && transform.position.x >= 8f){
			boundaryFlag = true;
		}
		if (Input.GetKey (KeyCode.RightArrow) && transform.position.x <= -8){
			boundaryFlag = true;
		}
	}
	void Flip ()
	{
		// Switch the way the player is labelled as facing.
		////facingRight = !facingRight;

		// Multiply the player's x local scale by -1.
		Vector2 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
	}

}
