﻿using UnityEngine;
using System.Collections;

public class CharizardCollider : MonoBehaviour {
	public GameObject gameManager;
	public GameManagerBuiltIn gmBuiltIn;
	public GameObject[] pokeballArray;
	public GameObject[] missileArray;
	public GameObject Charizard;
	//public bool gameEnd = false;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnTriggerEnter2D (Collider2D other){
		gameManager = GameObject.FindWithTag ("GameManager");
		Charizard = GameObject.FindWithTag ("Charizard1");
		missileArray = GameObject.FindGameObjectsWithTag ("Missile");
		gmBuiltIn = gameManager.GetComponent<GameManagerBuiltIn> ();
		gmBuiltIn.lives -= 1;
		pokeballArray = GameObject.FindGameObjectsWithTag("Pokeball");

		if (pokeballArray.Length == 0) {
			foreach (GameObject i in gmBuiltIn.Dragonite) {
				Destroy (i);
			}
			foreach (GameObject j in missileArray) {
				Destroy (j);
			}
			Destroy (Charizard);

		}
		else if (pokeballArray != null) {
			
			Destroy (pokeballArray [0]);
		}
	}
}
