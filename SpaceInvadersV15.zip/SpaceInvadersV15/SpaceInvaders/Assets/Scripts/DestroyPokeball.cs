﻿using UnityEngine;
using System.Collections;

public class DestroyPokeball : MonoBehaviour {
	public GameManagerBuiltIn gmBuiltIn;
	public GameObject gm;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		gm = GameObject.FindWithTag ("GameManager");
		gmBuiltIn = gm.GetComponent<GameManagerBuiltIn> ();
		if (gmBuiltIn.Dragonite.Length == 0){
			Destroy (gameObject);

			}
		}
	}
	

