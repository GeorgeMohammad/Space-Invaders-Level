﻿using UnityEngine;
using System.Collections;

public class DragoniteDestroy : MonoBehaviour {
	public GameObject gameManager;
	public GameManagerBuiltIn gmBuiltIn;
	public ScoreTracker scoreTracker;
	void OnTriggerEnter2d (Collider2D other){
		Destroy (gameObject);
	}
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		//Destroy (gameObject);
	}

	void OnTriggerEnter2D (Collider2D other){
		gameManager = GameObject.FindWithTag ("GameManager");
		gmBuiltIn = gameManager.GetComponent<GameManagerBuiltIn> ();
		scoreTracker = gameManager.GetComponent<ScoreTracker> ();
		scoreTracker.score += 5;
		Destroy (gameObject);
	}

}
