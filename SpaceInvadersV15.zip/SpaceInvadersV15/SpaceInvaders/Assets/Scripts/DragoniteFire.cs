﻿using UnityEngine;
using System.Collections;

public class DragoniteFire : MonoBehaviour {
	public Object GameManager;
	public Vector2 missilePosition;
	public Rigidbody2D missile;
	public Rigidbody2D missileInstance;
	public int dragoniteSelector;
	public GameObject gameManager;
	//public GameObject gameManagerBuiltInComponent;
	public GameManagerBuiltIn gameManagerBuiltInComponent;
	public int randomNumber;
	public float nextFire = 0;
	public float speed = -1f;
	public Vector3 missileDownShift = new Vector3(0, -1f);
	// Use this for initialization
	void Start () {
		gameManager = GameObject.FindWithTag ("GameManager");
		gameManagerBuiltInComponent = gameManager.GetComponent<GameManagerBuiltIn> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (Time.time > nextFire) {
			dragoniteSelector = gameManagerBuiltInComponent.Dragonite.Length;
			randomNumber = Random.Range (0, dragoniteSelector - 1);
			//missile.transform.position.x = gameManagerBuiltInComponent.Dragonite [dragoniteSelector].transform.position.x;
			//missile.transform.position.y = gameManagerBuiltInComponent.Dragonite [dragoniteSelector].transform.position.y;
			GameObject missileObject = gameManagerBuiltInComponent.Dragonite [randomNumber];
			missileInstance = Instantiate (missile, missileObject.transform.position, Quaternion.identity) as Rigidbody2D;
//			missileInstance.velocity =  new Vector2(0, speed);
			//missileInstance.AddForce(missileDownShift);
			nextFire = Time.time + 5;
		}
		if (missileInstance != null) {
			missileInstance.velocity = new Vector2 (0, speed);
		}
	}
}