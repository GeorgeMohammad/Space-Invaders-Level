﻿using UnityEngine;
using System.Collections;

public class DragoniteSpeedUp : MonoBehaviour {
	public float speedTimer = 1000;
	public float speedCounter = 0.0f;
	public GameManagerBuiltIn gmBuiltIn;
	public GameObject gameManager;
	public int currentTime;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		//currentTime = Time.time as int;

		if (Mathf.FloorToInt(Time.time) % speedTimer == 0) {
			gameManager = GameObject.FindWithTag ("GameManager");
			gmBuiltIn = gameManager.GetComponent<GameManagerBuiltIn> ();
			speedCounter += 0.2f;

			gmBuiltIn.speed  = speedCounter;

		}

	}
}
