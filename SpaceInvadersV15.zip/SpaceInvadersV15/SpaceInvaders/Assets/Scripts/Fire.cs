﻿using UnityEngine;
using System.Collections;

public class Fire : MonoBehaviour {
	public Rigidbody2D fireBall;
	public Rigidbody2D fireBallInstance;
	public GameObject[] charizardVariable;
	//public Vector2 fireBallPosition = new Vector2(0, -2f);
	public Vector2 fireBallPosition = new Vector2(0, -3f);

	public Vector2 fireBallUpShift = new Vector2 (0, 100);
	public float speed = 20f;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		charizardVariable = GameObject.FindGameObjectsWithTag("Charizard1");
		fireBallPosition.x = charizardVariable[0].transform.position.x;
		//fireBallPosition.y += charizardVariable[0].transform.position.y;
		if (Input.GetKeyDown (KeyCode.Space)) {
			

			fireBallInstance = Instantiate (fireBall, fireBallPosition, Quaternion.identity) as Rigidbody2D;
			fireBallInstance.velocity =  new Vector2(0, speed);

			/*******NOTE TO SELF: Must add a Translate statement to translate the instance of the fireball prefab.
			 *After that, I must use a collider. A potential function for the collider is
			 *defined below.
			 *******/
		}
	}

	void OnTriggerEnter2d(Collider2D other){
		//GameObject FireballPrefabComponent = GetComponent<FireballPrefab> () as GameObject;
		GameObject FireballPrefabComponent = GameObject.FindWithTag("FireballPrefab");
		//if (fireBallInstance.transform.position.y > 5) {
			Destroy (FireballPrefabComponent);
		//}
	}

}
