﻿using UnityEngine;
using System.Collections;

public class FireballDestroy : MonoBehaviour {
	public Rigidbody2D fireBall;
	public Vector2 fireBallPosition = new Vector2(0, -2f);
	public Object fireScriptComponent;
	public Rigidbody2D fireBallInstance;
	public float speed = 20f;

	public Object fireBallPrefabComponent;
	// Use this for initialization
	void OnTriggerEnter2D(Collider2D other){
		//Fire fireScriptComponent = GetComponent<Fire> ();
		//if (fireBallInstance.transform.position.y > 5) {
		//fireBallPrefabComponent = GetComponent<FireballPrefab>();
		GameObject FireballPrefabComponent = GameObject.FindWithTag("FireballPrefab");
		Destroy (gameObject);
		//}
	}
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		/*if(Input.GetKeyDown(KeyCode.Space)){
		fireBallInstance = Instantiate (fireBall, fireBallPosition, Quaternion.identity) as Rigidbody2D;
		fireBallInstance.velocity =  new Vector2(0, speed);
		}
		*/
		Fire fireScriptComponent = GetComponent<Fire> ();

/*		if (fireScriptComponent.fireBallInstance.transform.position.y > 1) {
		Destroy (gameObject);

*/
		//Destroy (gameObject);
		}
			


	/*void OnTriggerEnter2d(Collider2D other){
		//Fire fireScriptComponent = GetComponent<Fire> ();
		//if (fireBallInstance.transform.position.y > 5) {
		//fireBallPrefabComponent = GetComponent<FireballPrefab>();
		GameObject FireballPrefabComponent = GameObject.FindWithTag("FireballPrefab");
		Destroy (gameObject);
		//}
}
*/
}