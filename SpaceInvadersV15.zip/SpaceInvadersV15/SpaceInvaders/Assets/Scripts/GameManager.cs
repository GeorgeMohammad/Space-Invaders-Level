﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour 
{
	public int score;
	// Use this for initialization
	void Start () 
	{
	
	}
	void UpdateScore()

	{

	}
	// Update is called once per frame
	void Update () 
	{
		
	}
}
