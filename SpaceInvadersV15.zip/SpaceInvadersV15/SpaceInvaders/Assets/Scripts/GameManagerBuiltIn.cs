﻿using UnityEngine;
using System.Collections;

public class GameManagerBuiltIn : MonoBehaviour {

	public GameObject[] Dragonite;
    public Transform obj;
    public Transform fab;
    public Vector2 pos;
    public int wallSize = 5;
    public float walk = 10;
    public int x;
    public int y;
    public float xmax = 1;
    public float xmin = -1;
    public bool right = true; 
    public float delta;
    public float rightb = 8;
    public float leftb = -8;
	public GameObject[] allObjects;
	public int lives = 3;
	public GameObject pokeballLife1;
	public Vector3 pokeballLifePositionModifier = new Vector3(1, 0, 0);
	public Vector3 pokeballLifePosition2;
	public Vector3 pokeballLifePosition3;
	public GameObject Charizard;
	public GameObject[] charizardArray;
	public CharizardCollider charizardCollider;
	public bool destroyPokeball = true;
	public GameObject[] pokeBallArray;
	public Vector2 downShift = new Vector2 (0, 1);
	public bool downShiftCondition = false;
	public float speed = 1.0f;
	public GameObject Wall;
    void Start () {
        for (int x = 0; x < wallSize;x++) 
        {
            pos.x = x*1;
            for (int y = 0; y < wallSize;y++) 
            {
                pos.y = y*.95F;
				obj = Instantiate(fab, pos, Quaternion.identity) as Transform;
            }
        }
		Dragonite = GameObject.FindGameObjectsWithTag("Sprite");
		Debug.Log ("Press Escape to Quit.");
		pokeballLifePosition2 = pokeballLife1.transform.position + pokeballLifePositionModifier;
		pokeballLifePosition3 = pokeballLife1.transform.position + pokeballLifePositionModifier + pokeballLifePositionModifier;
		Object pokeballLifeInstance1 = Instantiate(pokeballLife1, pokeballLife1.transform.position, Quaternion.identity);
		Object pokeballLifeInstance2 = Instantiate(pokeballLife1, pokeballLifePosition2, Quaternion.identity);
		Object pokeballLifeInstance3 = Instantiate(pokeballLife1, pokeballLifePosition3, Quaternion.identity);
		Object wallInstance = Instantiate(Wall, new Vector2(-4, -2), Quaternion.identity);
		Object wallInstance2 = Instantiate(Wall, new Vector2(0, -2), Quaternion.identity);
		Object wallInstance3 = Instantiate (Wall, new Vector2 (4, -2), Quaternion.identity);
    }

    public void rotateRandomObject() 
    {
		int i = Random.Range(0, Dragonite.Length); // max is exclusive
        Debug.Log("Random = "+i.ToString());
		Dragonite[i].transform.Rotate(Vector3.forward * (i+1) * 45);
    }
	public void destroyAllObjects(){
		if (Input.GetKeyDown (KeyCode.Escape)) {
			allObjects = Object.FindObjectsOfType<GameObject> ();
			foreach (GameObject i in allObjects) {
				Destroy (i);
			}
		}
	}
	//void lifeManager(){
	void SceneDestroyer(){
		//pokeballArray = GameObject.FindGameObjectsWithTag("Pokeball");

		charizardArray = GameObject.FindGameObjectsWithTag ("Charizard1");
		if (charizardArray.Length == 0) {
			Charizard = GameObject.FindWithTag ("Charizard1");
			charizardCollider = Charizard.GetComponent<CharizardCollider> ();
		}
		if (Dragonite == null) {
			if (charizardCollider.pokeballArray == null) {
				destroyPokeball = false;
			}
			if (destroyPokeball) {
				foreach (GameObject i in charizardCollider.pokeballArray) {
					Destroy (i);
				}
			}
				}
			}


	
	void DestroyPlayer(){
		Destroy(Charizard);
	}
	void SceneBuilder() {
		
	}
	//}
    void Update() 
    {
		//if (Input.GetKeyDown (KeyCode.Escape)) {
		//	Application.Quit ();
		//}
        if (right)
            delta = Time.deltaTime;
        else
            delta = -Time.deltaTime;
		

		Dragonite = GameObject.FindGameObjectsWithTag("Sprite");

        xmax = 0;
        xmin = 0;
		foreach (GameObject object1 in Dragonite)
        {
			object1.transform.Translate(walk * delta * speed ,0,0,Space.World);

			if (object1.transform.position.x > xmax)
				xmax = object1.transform.position.x;
			if (object1.transform.position.x < xmin)
				xmin = object1.transform.position.x;
        }

        if (xmax > rightb)
            right = false;
        if (xmin < leftb)
            right = true;
		

		else if (Input.GetKeyDown (KeyCode.Escape)) {
			allObjects = Object.FindObjectsOfType<GameObject> ();
			foreach (GameObject i in allObjects) {
				Destroy (i);
			} 
		}
		/*foreach (GameObject i in Dragonite) {
			if (i.transform.position.x == 8) {
				downShiftCondition = true;
			}
			if (downShiftCondition){
				foreach (GameObject j in Dragonite) {
					/*downShift = j.transform.position;
					downShift.y -= 1;
					j.transform.position = downShift;

					j.transform.Translate (0, -1, 0);
			//j.transform.position.y -= 1;
				}
			}
			}
		*/

		}
	}

