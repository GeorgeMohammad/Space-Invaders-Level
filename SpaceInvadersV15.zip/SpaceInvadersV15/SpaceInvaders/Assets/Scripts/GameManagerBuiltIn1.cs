﻿using UnityEngine;
using System.Collections;

public class GameManagerBuiltIn1 : MonoBehaviour {

    public GameObject[] cylinders;
    public Transform obj;
    public Transform fab;
    public Vector3 pos;
    public int wallSize = 5;
    public float walk = 10;
    public int x;
    public int y;
    public float xmax;
    public float xmin;
    public bool right = true; 
    public float delta ;
    public float rightb = 15;
    public float leftb = -10;


    void Start () {
        for (int x = 0; x < wallSize;x++) 
        {
            pos.x = x*2;
            for (int y = 0; y < wallSize;y++) 
            {
                pos.y = y*3;
                obj = Instantiate(fab, pos, Quaternion.identity) as Transform;
            }
        }
        cylinders = GameObject.FindGameObjectsWithTag("Sprite");
    }

    public void rotateRandomObject() 
    {
        int i = Random.Range(0, cylinders.Length); // max is exclusive
        Debug.Log("Random = "+i.ToString());
        cylinders[i].transform.Rotate(Vector3.forward * (i+1) * 45);
    }

    void Update() 
    {
        if (right)
            delta = Time.deltaTime;
        else
            delta = -Time.deltaTime;

        //cylinders = GameObject.FindGameObjectsWithTag("Sprite");

        xmax = 0;
        xmin = 0;
		foreach (GameObject cylinder in cylinders)
        {
            cylinder.transform.Translate(walk * delta,0,0,Space.World);

            if (cylinder.transform.position.x > xmax)
                xmax = cylinder.transform.position.x;
            if (cylinder.transform.position.x < xmin)
                xmin = cylinder.transform.position.x;
        }

        if (xmax > rightb)
            right = false;
        if (xmin < leftb)
            right = true;
    }

}
