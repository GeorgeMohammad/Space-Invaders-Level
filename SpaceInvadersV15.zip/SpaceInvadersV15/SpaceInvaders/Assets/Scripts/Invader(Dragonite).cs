﻿using UnityEngine;
using System.Collections;

public class Invader : MonoBehaviour 
{
	public GameObject[] DragoniteArray = new GameObject[25];
	public Vector3 xShift = new Vector3(5, 0, 0);
	public GameObject[] Dragonite = new GameObject[1];
	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		DragoniteArray = GameObject.FindGameObjectsWithTag("Dragonite");

		for (int i = 0; i < DragoniteArray.Length; i++) 
		{
			//DragoniteArray[i] = Dragonite;
		}
		for (int x = 0; x <= 5; x++)
		{
			Instantiate(DragoniteArray[x], transform.position, Quaternion.identity);
			DragoniteArray [x].transform.Translate (xShift);
		}
	}
}
