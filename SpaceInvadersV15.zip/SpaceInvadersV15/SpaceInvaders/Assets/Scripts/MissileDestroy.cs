﻿using UnityEngine;
using System.Collections;

public class MissileDestroy : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (gameObject.transform.position.y < -6) {
			Destroy (gameObject);
		}
	}
	void OnTriggerEnter2D(Collider2D other){
		if (gameObject != null) {
			Destroy (gameObject);
		}
	}
}
