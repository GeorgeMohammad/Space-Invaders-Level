﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {
	public GameObject player;
	public Vector3 playerPos = new Vector3(0, -3.9f, 0);
	// Use this for initialization
	void Start () {
		Instantiate (player, playerPos, Quaternion.identity);
	}

	// Update is called once per frame
	void Update () {
	}

}