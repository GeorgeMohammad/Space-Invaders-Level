﻿using UnityEngine;
using System.Collections;

public class SceneBuilder1 : MonoBehaviour {
	public GameObject gameManager;
	public GameManagerBuiltIn gmBuiltIn;
	public GameObject[] Charizard;
	public GameObject[] pokeballs;
	public GameObject[] missiles;
	public GameObject[] walls;
	public GameObject player;
	public Player playerComponent;
	public bool charizardFlag = true;
	// Use this for initialization
	void Start () {
		gameManager = GameObject.FindWithTag ("GameManager");
		gmBuiltIn = gameManager.GetComponent<GameManagerBuiltIn> ();
		pokeballs = GameObject.FindGameObjectsWithTag ("Pokeball");
		missiles = GameObject.FindGameObjectsWithTag("Missile");
		walls = GameObject.FindGameObjectsWithTag ("Wall");
	}

	// Update is called once per frame
	void Update () {
		Charizard = GameObject.FindGameObjectsWithTag ("Charizard1");
		pokeballs = GameObject.FindGameObjectsWithTag ("Pokeball");
		missiles = GameObject.FindGameObjectsWithTag("Missile");
		player = GameObject.FindWithTag ("Player");
		playerComponent = player.GetComponent<Player> ();
		if (pokeballs.Length == 0) {
			gmBuiltIn.pokeballLifePosition2 = gmBuiltIn.pokeballLife1.transform.position + gmBuiltIn.pokeballLifePositionModifier;
			gmBuiltIn.pokeballLifePosition3 = gmBuiltIn.pokeballLife1.transform.position + gmBuiltIn.pokeballLifePositionModifier + gmBuiltIn.pokeballLifePositionModifier;
			Object pokeballLifeInstance1 = Instantiate(gmBuiltIn.pokeballLife1, gmBuiltIn.pokeballLife1.transform.position, Quaternion.identity);
			Object pokeballLifeInstance2 = Instantiate(gmBuiltIn.pokeballLife1, gmBuiltIn.pokeballLifePosition2, Quaternion.identity);
			Object pokeballLifeInstance3 = Instantiate(gmBuiltIn.pokeballLife1, gmBuiltIn.pokeballLifePosition3, Quaternion.identity);
			Object charizardInstance = Instantiate (playerComponent.player, playerComponent.playerPos, Quaternion.identity);
		}
		if (gmBuiltIn.Dragonite.Length == 0){
			StartCoroutine (DelayFunction ());
			//Charizard = GameObject.FindGameObjectsWithTag ("Charizard1");




			for (int x = 0; x < gmBuiltIn.wallSize;x++) 
			{
				gmBuiltIn.pos.x = x*1;
				for (int y = 0; y < gmBuiltIn.wallSize;y++) 
				{
					gmBuiltIn.pos.y = y*.95F;
					gmBuiltIn.obj = Instantiate(gmBuiltIn.fab, gmBuiltIn.pos, Quaternion.identity) as Transform;
				}
			}
			gmBuiltIn.Dragonite = GameObject.FindGameObjectsWithTag("Sprite");
			//Debug.Log ("Press Escape to Quit.");
			/*gmBuiltIn.pokeballLifePosition2 = gmBuiltIn.pokeballLife1.transform.position + gmBuiltIn.pokeballLifePositionModifier;
			gmBuiltIn.pokeballLifePosition3 = gmBuiltIn.pokeballLife1.transform.position + gmBuiltIn.pokeballLifePositionModifier + gmBuiltIn.pokeballLifePositionModifier;
			Object pokeballLifeInstance1 = Instantiate(gmBuiltIn.pokeballLife1, gmBuiltIn.pokeballLife1.transform.position, Quaternion.identity);
			Object pokeballLifeInstance2 = Instantiate(gmBuiltIn.pokeballLife1, gmBuiltIn.pokeballLifePosition2, Quaternion.identity);
			Object pokeballLifeInstance3 = Instantiate(gmBuiltIn.pokeballLife1, gmBuiltIn.pokeballLifePosition3, Quaternion.identity);
			Object charizardInstance = Instantiate (playerComponent.player, playerComponent.playerPos, Quaternion.identity);
			Camera.main.backgroundColor = Color.red;
			*/
			foreach (GameObject i in Charizard) {
				Destroy (i);
				Object charizardInstance = Instantiate (playerComponent.player, playerComponent.playerPos, Quaternion.identity);

			}
		}
		else if (Charizard.Length == 0 && charizardFlag) {
			Object charizardInstance = Instantiate (playerComponent.player, playerComponent.playerPos, Quaternion.identity);
			charizardFlag = false;
		}

	if (walls.Length == 0){
		Object wallInstance = Instantiate(gmBuiltIn.Wall, new Vector2(-4, -2), Quaternion.identity);
		Object wallInstance2 = Instantiate(gmBuiltIn.Wall, new Vector2(0, -2), Quaternion.identity);
		Object wallInstance3 = Instantiate (gmBuiltIn.Wall, new Vector2 (4, -2), Quaternion.identity);
	}
	}

	IEnumerator DelayFunction(){
		yield return new WaitForSeconds (10000000000);
	}
}
