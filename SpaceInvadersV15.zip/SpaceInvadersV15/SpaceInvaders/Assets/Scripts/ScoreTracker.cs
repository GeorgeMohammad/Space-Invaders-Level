﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class ScoreTracker : MonoBehaviour {
	public int score = 0;
	//public string scoreString;
	public Text scoreText;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (score > PlayerPrefs.GetInt ("High Score")) {
			//scoreString = score.ToString;
			PlayerPrefs.SetInt ("High Score", score);
		}

		//scoreString = PlayerPrefs.GetInt ("High Score");
		scoreText.text = "High Score: " + PlayerPrefs.GetInt("High Score");

		//PlayerPrefs.SetInt("High Score", 0);
	}
}
